# Certifiable Registration

A Branch-and-Bound global optimization algorithm for Truncated Least Squares optimization for point cloud registration. 

# Install dependencies and build
Tested on:

- Windows
- Ubuntu Linux 22.04 LTS

Thanks to conan, this package is not dependent on the system package manager on Linux, therefore it probabably works on other Linux distros too, just give it a try !

Note to Windows users: Do not use Python from the Microsoft Store, this may lead to the conan-command not being installed correctly, instead install Python from python.org


Install conan2: 
```sh
pip install conan~=2.0
```

Do this once:

```sh
conan profile detect
```

Now install the dependencies with conan:

```sh
conan install . --build=missing --output build
```

Compile and install the pip package with CMake: 

### Linux 

```sh
mkdir Release
cd Release
cmake .. -DCMAKE_TOOLCHAIN_FILE=conan_toolchain.cmake -DCMAKE_BUILD_TYPE=Release
cmake --build . --target install
```

### Windows
- Install newest Visual Studion Compiler.

```sh
mkdir Release
cd Release
cmake .. -G "Visual Studio 17 2022" -DCMAKE_TOOLCHAIN_FILE="conan_toolchain.cmake"
cmake --build . --config Release --target install
```

# Debug build 

Note that for debug build you have to tell it to conan, you cannot set it with CMake ! (i.e. via `-DCMAKE_BUILD_TYPE=`)
(If you try `-DCMAKE_BUILD_TYPE=`, you get header-not found compilation errors)

You have to do:
### Linux 
```sh
mkdir Debug
conan install . -s "&:build_type=Debug" -s build_type=Release --output Debug
cd Debug
cmake .. -DCMAKE_TOOLCHAIN_FILE=conan_toolchain.cmake
cmake --build . ---target install
```

### Windows 

```sh
mkdir Debug
conan install . -s "&:build_type=Debug" -s build_type=Release --output Debug
cd Debug
cmake .. -G "Visual Studio 17 2022" -DCMAKE_TOOLCHAIN_FILE="conan_toolchain.cmake"
cmake --build . --config Debug --target install --verbose
```

Note also that the `--verbose` flag is required to CMake to see the full compiler output with MSVC. CMake 
has a bug-feature that it hides some parts of the compiler error messages that aren't actually "overly verbose" and rather needed most of the time, i.e. where a static-assert was triggered. This is required for figuring out why Eigen-code does not compile.


Reference: 
https://github.com/conan-io/conan/issues/12656
https://github.com/conan-io/conan/issues/12656

## Run C++ example 

```sh
.\Debug\Debug\test_bnb.exe -data_file test_data\eval_problems\synthetic_data_pose_50_0.1.h5 -mode "pose" -pause_before_run true -debug_print true
```


# Evaluation 
To run the evaluation and plotting, install first the python dependencies:

`pip install -r requirements.txt`

## Test on specific instance 

```sh
python evaluate_bnb_certifier.py run_on_hdf5_instance "../test_data/synthetic_data_N=50_adversarial_suboptimality=0.97_outlier_rate=0.0_eps=0.1_i=31.h5"
```

# How to profile with perf:

There is test data in this folder for the different problems. 
after building, go in the root folder. Then:

```sh
./build/test_bnb
ps aux | grep test_bnb # Determine pid 
perf record -o certifiable_registration_rot_bnb.data --call-graph dwarf --freq=16000 --aio --sample-cpu --pid <the pid> 
perf script -i certifiable_registration_rot_bnb.data > certifiable_registration_rot_bnb.txt
```

Its normal that the last command takes long with the crypic message 
`addr2line [...] could not read first record`. 

Then, analyze the recorded data with a tool such as hotspot or the firefox profiler or https://www.speedscope.app/
https://profiler.firefox.com/



